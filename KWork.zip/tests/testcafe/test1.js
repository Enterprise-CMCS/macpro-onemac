import { Selector } from 'testcafe';

fixture `Getting Started`
    .page `${process.env.APPLICATION_ENDPOINT}`;

test('My first test', async t => {
    // Test code
});
