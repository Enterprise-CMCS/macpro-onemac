#!/bin/bash

set -e

pushd tests
sh test.sh
popd
